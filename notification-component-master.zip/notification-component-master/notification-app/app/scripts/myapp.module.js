'use strict';

angular.module('myApp', ['myApp.homepage']);

