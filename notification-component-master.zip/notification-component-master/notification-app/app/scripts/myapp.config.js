'use strict';

angular.module('myApp');
