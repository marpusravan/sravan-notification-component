'use strict';

angular.module('myApp.homepage')
  .factory('ServerData', function($websocket) {
      // Open a WebSocket connection
      /*var dataStream = $websocket('ws://website.com/data');

      var collection = [];

      dataStream.onMessage(function(message) {
        collection.push(JSON.parse(message.data));
        console.log("TEST");
      });

      var methods = {
        collection: collection,
        get: function() {
          dataStream.send(JSON.stringify({ action: 'get' }));
          console.log("TESTdd");
        }
      };

      return methods;*/
    })