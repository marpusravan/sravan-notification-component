'use strict';

angular
  .module('myApp.homepage', [
    'ngCookies',
    'ngResource',
    'ngSanitize',
    'ngRoute',
    'angularMoment',
    'ngWebSocket',
    'ngMaterial'
  ])
  .config(function ($routeProvider, $locationProvider) {
    $routeProvider
      .when('/', {
        templateUrl: 'views/homepage.html',
        controller: 'HomepageCtrl'
      })
      .otherwise({
        redirectTo: '/'
      });

       $locationProvider.html5Mode(true);
  }).run(function () {

    });
