angular
.module('myApp.homepage')
.component('notifications', {
    bindings: {
      items: '<',
      onRemove:'&'
    },
    templateUrl: 'views/notification.html'
});