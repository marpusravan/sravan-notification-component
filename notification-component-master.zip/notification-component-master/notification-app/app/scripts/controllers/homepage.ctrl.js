'use strict';

angular.module('myApp.homepage')
  .controller('HomepageCtrl', ['$scope','$mdSidenav','moment','$websocket', function ($scope, $mdSidenav, moment, $websocket ) {
    
  $scope.currentDate = new Date();

  $scope.messages = {
        items : [], 
        assignTask : {
            count:0, 
            code:"assignTask",
            displayName : "Assigned Tasks"
        },
        reminder : {
            count:0, 
            code:"reminder",
            displayName : "Reminders"
        },
        notifications : {
            count:0, 
            code :"notifications",
            displayName : "Notifications"
        }
    }
   
  	$scope.addTask = function(taskType, linkText) {
  		$scope.messages.items.unshift({time:new Date(), task:taskType+"Click Task", type:taskType, linkText:linkText});
  	}

  	$scope.removeItem = function(index) {
  		$scope.messages.items.splice(index, 1);		
  	};

    $scope.isOpenRight = function(){
      return $mdSidenav('right').isOpen();
    };


   $scope.toggleRight = buildToggler('right');

   function buildToggler(navID) {
      return function() {
        // Component lookup should always be available since we are not using `ng-if`
        $mdSidenav(navID)
          .toggle()
          .then(function () {
            
          });
      };
    }

    var dataStream = $websocket('ws://localhost:8080');
    var collection = [];
    dataStream.onMessage(function(message) {
        var json = JSON.parse(message.data);
        console.log(json);
        json.time = new Date();
        $scope.messages.items.push(json);
        $scope.$apply();
        setTimeout(function(){ dataStream.send("message") }, 2000);
    });

  }]);
