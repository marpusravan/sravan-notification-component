'use strict';

angular.module('myApp.homepage').controller('SideNavCtrl', function($scope, $mdSidenav, moment) {

	$scope.close = function () {
      // Component lookup should always be available since we are not using `ng-if`
      $mdSidenav('right').close()
        .then(function () {
        
        });
    };
  
});